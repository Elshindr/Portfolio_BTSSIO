#!/bin/bash
###############################################################################
##                                                                           ##
## Auteur : José GIL                                                         ##
##                                                                           ## 
## Synopsis : Script d’installation et de configuration automatique d'un     ##
##            serveur LAMP (Apache, MySQL, PHP et phpMyAdmin) avec les       ##
##            dernières versions.                                            ##
##                                                                           ##
## Date : 16/01/2021                                                         ##
##                                                                           ##
## Scénario :                                                                ##
##      1. Récupération d'un dépôt GitHub                                    ##
##      2. Configuration d'Apache                                            ##
##      3. Restauration du contexte WordPress dans MySQL                     ##
##                                                                           ##
###############################################################################

# Test pour savoir si exécute le script en tant que root, sinon sudo !
if [ "$(whoami)" != "root" ]; then
    SUDO=sudo
fi

# Sortir du script en cas d'erreur
set -e

# Variables 
FICHIER_DE_LOG="`echo $HOME`/post-install.log"
MOT_DE_PASSE_ADMIN_MYSQL="P@ssw0rdMySQL"

# Création du fichier de log
if [ ! -f $FICHIER_DE_LOG ]
then
    touch $FICHIER_DE_LOG
fi

# Fonction pour l'affichage écran et la journalisation dans un fichier de log
suiviInstallation() 
{
    echo "# $1"
	${SUDO} echo "# $1" &>>$FICHIER_DE_LOG
    ${SUDO} bash -c 'echo "#####" `date +"%d-%m-%Y %T"` "$1"' &>>$FICHIER_DE_LOG
}

# Fonction qui gère l'affichage d'un message de réussite
toutEstOK()
{
    echo -e "  '--> \e[32mOK\e[0m"
}

# Fonction qui gère l'affichage d'un message d'erreur et l'arrêt du script en cas de problème
erreurOnSort()
{
    echo -e "\e[41m" `${SUDO} tail -1 $FICHIER_DE_LOG` "\e[0m"
    echo -e "  '--> \e[31mUne erreur s'est produite\e[0m, consultez le fichier \e[93m$FICHIER_DE_LOG\e[0m pour plus d'informations"
    exit 1
}

# Restauration du site WordPress depuis le dépôt GitHub
suiviInstallation "Restauration du site WordPress"
cd /var/www/html
# Récupération du dépôt GitHub (attention à bien modifier les informations de connexion)
suiviInstallation "Récupération du dépôt GitHub"
${SUDO} git clone https://<UtilisateurGitHub>:<TOKEN>@github.com/AmeliaPilou/b13wp2cloud.git
cd b13wp2cloud/
# Sécurisation des permissions sur les fichiers
suiviInstallation "Sécurisation des permissions sur les fichiers"
${SUDO} chown -R www-data:www-data www/ &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} find www/ -type d -exec chmod 755 {} \; &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} find www/ -type f -exec chmod 644 {} \; &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
# Configuration de Apache pour spécifier le dossier d'hébergement par défaut sur serveur web
suiviInstallation "Configuration de Apache"
${SUDO} sed -i "s/^\tDocumentRoot \/var\/www\/html/\tDocumentRoot \/var\/www\/html\/b13wp2cloud\/www/" /etc/apache2/sites-available/000-default.conf &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} sed -i "/^<\/VirtualHost>/i \\\t<Directory \/var\/www\/html\/b13wp2cloud\/www/>" /etc/apache2/sites-available/000-default.conf &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} sed -i "/^<\/VirtualHost>/i \\\t\\tOptions Indexes FollowSymLinks" /etc/apache2/sites-available/000-default.conf &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} sed -i "/^<\/VirtualHost>/i \\\t\\tAllowOverride All" /etc/apache2/sites-available/000-default.conf &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} sed -i "/^<\/VirtualHost>/i \\\t\\tRequire all granted" /etc/apache2/sites-available/000-default.conf &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} sed -i "/^<\/VirtualHost>/i \\\t<\/Directory>" /etc/apache2/sites-available/000-default.conf &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} a2enmod rewrite &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
${SUDO} service apache2 restart &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort
suiviInstallation "Restauration des données et privilèges dans MySQL"
# Restauration du fichier SQL de la BDD pour import du contexte
suiviInstallation "Création de la BDD pour affectation des privilèges"
${SUDO} mysql -u root -p${MOT_DE_PASSE_ADMIN_MYSQL} < cfi-restore-test-azure.sql &>>$FICHIER_DE_LOG && toutEstOK || erreurOnSort

