VirtualHost d'origine : http://centredeformationinformatique.fr

Identifiants du compte admin WordPress :
 - Nom d'utilisateur : admincfi
 - Mot de passe : uA%LezR^AyS(P6bqua

